package main

import (
	_ "embed"
	"fmt"
	"iter"
	"os"
	"path/filepath"
	"strings"

	"gioui.org/layout"
	"github.com/ddkwork/golibrary/std/mylog"
	"github.com/ddkwork/golibrary/std/stream"
	"github.com/ddkwork/ux/widget/menu"
	treetable2 "github.com/ddkwork/ux/widget/treetable"
	"golang.org/x/sys/windows/registry"
)

//go:generate go build -x .
//go:generate go install .

// https://faststone-photo-resizer.en.lo4d.com/windows

type EnvironmentEditor struct {
	Key     string
	Value   string
	IsValid bool
	Type    kind
}

func Layout() *treetable2.TreeTable[EnvironmentEditor] {
	t := treetable2.NewTreeTable[EnvironmentEditor]()
	t.AirTable.TableContext = treetable2.TableContext{
		CustomContextMenuItems: func(gtx layout.Context, n *treetable2.Node) iter.Seq[*menu.MenuItem] {
			return func(yield func(*menu.MenuItem) bool) {}
		},
		RowSelectedCallback:    func() {},
		RowDoubleClickCallback: func() {},
		SetRootRowsCallBack:    func() { setRootRowsCallBack(t) },
		JsonName:               "RapidEnvironmentEditor",
	}
	return t
}

func setRootRowsCallBack(treeTable *treetable2.TreeTable[EnvironmentEditor]) {
	const EnvPath = `SYSTEM\CurrentControlSet\Control\Session Manager\Environment`
	key := mylog.Check2(registry.OpenKey(registry.LOCAL_MACHINE, EnvPath, registry.ALL_ACCESS))
	valueNames := mylog.Check2(key.ReadValueNames(-1))

	containers := make([]*treetable2.Node, 0)

	for _, valueName := range valueNames {
		value, valueType := mylog.Check3(key.GetStringValue(valueName))

		if strings.Contains(value, ";") {
			v := value
			container := treeTable.NewContainerNode(valueName, EnvironmentEditor{
				Key:     valueName,
				Value:   "",
				IsValid: false,
				Type:    kind(valueType),
			})
			container.SetParent(treeTable.Root())
			container.SetOpen(true)
			containers = append(containers, container)

			children := make([]*treetable2.Node, 0)
			validCount := 0
			for value := range strings.SplitSeq(v, ";") {
				isValid := isValidPath(value)
				if isValid {
					validCount++
				}
				child := treeTable.NewNode(EnvironmentEditor{
					Key:     valueName,
					Value:   value,
					IsValid: isValid,
					Type:    kind(valueType),
				})
				child.SetParent(container)
				children = append(children, child)
			}
			container.SetChildren(children)

			childCount := len(children)
			for i := range container.RowCells {
				if container.RowCells[i].ColumnName == "Value" {
					container.RowCells[i].Value = fmt.Sprintf("%d items", childCount)
				}
				if container.RowCells[i].ColumnName == "IsValid" {
					container.RowCells[i].Value = fmt.Sprintf("%d/%d", validCount, childCount)
				}
			}
		} else {
			container := treeTable.NewNode(EnvironmentEditor{
				Key:     valueName,
				Value:   value,
				IsValid: isValidPath(value),
				Type:    kind(valueType),
			})
			container.SetParent(treeTable.Root())
			container.SetOpen(true)
			containers = append(containers, container)
		}
	}

	treeTable.Root().SetChildren(containers)
	treeTable.Root().OpenAll()
}

func isValidPath(path string) bool {
	switch {
	case strings.Contains(path, "items"):
		return true
	case path == "":
		return false
	case !strings.Contains(path, "\\") && !strings.Contains(path, "/"):
		return true
	case strings.HasPrefix(path, `%`):
		split := strings.Split(path, `%`)
		env := os.Getenv(split[1])
		path = filepath.Join(env, split[2])
		ext := filepath.Ext(path)
		if ext == "" {
			return stream.IsDirEx(path)
		}
		return stream.IsFilePathEx(path)
	default:
		return stream.IsDirEx(path)
	}
}

type kind byte

const (
	NONE kind = iota
	SZ
	EXPAND_SZ
	BINARY
	DWORD
	DWORD_BIG_ENDIAN
	LINK
	MULTI_SZ
	RESOURCE_LIST
	FULL_RESOURCE_DESCRIPTOR
	RESOURCE_REQUIREMENTS_LIST
	QWORD
)

func (k kind) String() string {
	switch k {
	case NONE:
		return "NONE"
	case SZ:
		return "SZ"
	case EXPAND_SZ:
		return "EXPAND_SZ"
	case BINARY:
		return "BINARY"
	case DWORD:
		return "DWORD"
	case DWORD_BIG_ENDIAN:
		return "DWORD_BIG_ENDIAN"
	case LINK:
		return "LINK"
	case MULTI_SZ:
		return "MULTI_SZ"
	case RESOURCE_LIST:
		return "RESOURCE_LIST"
	case FULL_RESOURCE_DESCRIPTOR:
		return "FULL_RESOURCE_DESCRIPTOR"
	case RESOURCE_REQUIREMENTS_LIST:
		return "RESOURCE_REQUIREMENTS_LIST"
	case QWORD:
		return "QWORD"
	default:
		return "unknown"
	}
}
